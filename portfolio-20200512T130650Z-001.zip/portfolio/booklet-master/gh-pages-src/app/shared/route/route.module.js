(function() {
	'use strict';

	angular.module('shared.route', [
		'ngRoute',
		'shared.logger'
	]);

})();
