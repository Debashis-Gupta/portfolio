﻿'use strict';

describe('shared.config', function() {
	beforeEach(module('app.config'));

	it('should pass a dummy test', function() {
		expect(3).toEqual(3);
	});
});
