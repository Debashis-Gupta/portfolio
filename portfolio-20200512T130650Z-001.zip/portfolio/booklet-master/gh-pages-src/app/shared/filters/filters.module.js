(function() {
	'use strict';

	angular.module('shared.filters', []);

})();
